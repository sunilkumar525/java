# spring-boot-ajax
How to call rest API using Jquery and Ajax
